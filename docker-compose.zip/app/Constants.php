<?php

namespace App;

class Constants{

    # user status
    const USER = 0;
    const USER_ADMIN = 1;

    # user gender
    const FEMALE = 0;
    const MALE = 1;

    #products status
    const ACTIVE = 1;
    const NOT_ACTIVE = 0;
}

?>
