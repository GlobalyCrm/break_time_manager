

<?php $__env->startSection('title'); ?>
    <?php echo e(translate_title("Language translate")); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="card mt-4">
        <div class="card-body">
            <form class="form-horizontal" action="<?php echo e(route('translation.save')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <input type="hidden" id="language_code" value="<?php echo e($language->code??''); ?>">
                <input type="hidden" name="id" value="<?php echo e($language->id??''); ?>">

                <div class="right_button_create">
                    <h4 class=""><?php echo e($language->name??''); ?></h4>
                </div>
                <table class="table datatable table-striped table-bordered dt-responsive nowrap">
                    <thead>
                    <tr>
                        <th>#</th>
                        <th><?php echo e(translate_title('Key')); ?></th>
                        <th> <?php echo e(translate_title('Translation')); ?></th>
                    </tr>
                    </thead>

                    <tbody>
                    <?php if(count($lang_keys) > 0): ?>
                        <?php
                            $n = 1;
                        ?>
                        <?php $__currentLoopData = $lang_keys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $translation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($n++); ?></td>
                                <td class="lang_key"><?php echo e($translation->lang_key??''); ?></td>
                                <td class="lang_value">
                                    <input type="text" class="form-control value" id="input"
                                           style="width:100%" name="values[<?php echo e($translation->lang_key??''); ?>]"
                                           <?php if(($traslate_lang = \App\Models\Translation::where('lang', $language->code??'')->where('lang_key', $translation->lang_key??'')->first()) != null): ?> value="<?php echo e($traslate_lang->lang_value??''); ?>" <?php endif; ?>>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                    </tbody>
                </table>
                <div class="row ">
                    <div class="col-xl-6 col-md-6">

                    </div>
                    <div class="col-xl-6 col-md-6">
                        <div class="form-group mt-2 text-right">
                            <button type="button" class="btn edit_button"
                                    onclick="copyTranslation()"><?php echo e(translate_title('Copy Translations')); ?></button>
                            <button type="submit" class="btn delete_button"><?php echo e(translate_title('Save')); ?></button>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>


<script src="<?php echo e(asset('js/language.js')); ?>"></script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\work\resources\views/language/show.blade.php ENDPATH**/ ?>