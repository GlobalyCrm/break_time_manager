

<?php $__env->startSection('title'); ?>
    <?php echo e(translate_title("Language translate")); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div id="loader"></div>
    <div class="main-content-section d-none" id="myDiv">
        <div class="order-section">
            <ul class="nav nav-tabs" id="myTab" role="tablist">
                <li class="nav-item ms-2 mb-2" role="presentation">
                    <a class="nav-link active" id="language-tab" data-bs-toggle="tab" href="#language" role="tab" aria-controls="language" aria-selected="true"><?php echo e(translate_title('Translate')); ?></a>
                </li>
                <li class="nav-item ms-2 mb-2" role="presentation">
                    <a class="nav-link" id="table-translate-tab" data-bs-toggle="tab" href="#table-translate" role="tab" aria-controls="table-translate" aria-selected="false"><?php echo e(translate_title('Table translate')); ?></a>
                </li>
            </ul>
            <div class="card mt-4">
                <div class="card-body">
                    <div class="tab-content" id="myTabContent">
                        <div class="tab-pane fade show active" id="language" role="tabpanel" aria-labelledby="language-tab">
                            <form class="parsley-examples" action="<?php echo e(route('env_key_update.update')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <div class="row">
                                    <div class="col-md-4">
                                        <h2><?php echo e(translate_title('Default language')); ?></h2>
                                    </div>
                                    <div class="col-md-2 ">
                                        <div class=" mt-2">
                                            <input type="hidden" name="types[]" value="DEFAULT_LANGUAGE">
                                            <select  class="form-select"    id="country" name="DEFAULT_LANGUAGE">
                                                <?php $__currentLoopData = $languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($language->code??''); ?>" <?php if (env('DEFAULT_LANGUAGE') == $language->code??'') {
                                                        echo 'selected';
                                                    } ?>>
                                                        <?php echo e($language->name??''); ?>

                                                    </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <button type="submit" class="btn edit_button mt-2"><?php echo e(translate_title('Save')); ?></button>
                                    </div>
                                </div>

                            </form>
                            <table class="table mt-2" style="text-align:center !important">
                                <thead class="table-light">
                                    <tr>
                                        <th scope="row">№</th>
                                        <td><?php echo e(translate_title('Language')); ?></td>
                                        <td><?php echo e(translate_title('Code')); ?></td>
                                        <td><?php echo e(translate_title('Action')); ?></td>
                                    </tr>
                                </thead>
                                <tbody class="text-align:center !important">
                                <?php if(empty(!$languages)): ?>
                                    <?php
                                        $i = 1;
                                    ?>

                                    <?php $__currentLoopData = $languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <th scope="row"><?php echo e($i++); ?></th>
                                            <td> <?php echo e($value->name??''); ?></td>
                                            <td><?php echo e($value->code??''); ?></td>
                                            <td>
                                                <a href="<?php echo e(route('language.show', $value->id)); ?>"
                                                   title="<?php echo e(translate_title('Translation')); ?>"  >
                                                    <button type="button" class="btn edit_button waves-effect waves-light">
                                                        <i class="fa fa-language"></i>
                                                    </button>
                                                </a>
                                                <a href="<?php echo e(route('language.edit', encrypt($value->id))); ?>">
                                                    <button type="button" class="btn edit_button waves-effect waves-light">
                                                        <img src="<?php echo e(asset('img/edit_icon.png')); ?>" alt="" height="18px">
                                                    </button>
                                                </a>
                                                <?php if($value->code != 'en'): ?>
                                                    <button type="button" class="btn delete_button" data-bs-toggle="modal" data-bs-target="#delete_modal" data-url="<?php echo e(route('language.destroy', $language->id)); ?>">
                                                        <img src="<?php echo e(asset('img/trash_icon.png')); ?>" alt="" height="18px">
                                                    </button>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                        <div class="tab-pane fade" id="table-translate" role="tabpanel" aria-labelledby="table-translate-tab">
                            <div class="justify-content-center">
                                <ul class="translation_content">
                                    <li class="translation_list">
                                        <a href="<?php echo e(route('table.show', 'city')); ?>"><div class="translation_menu"><?php echo e(translate_title('City translate')); ?></div></a>
                                    </li>
                                    <li class="translation_list">
                                        <a href="<?php echo e(route('table.show', 'category')); ?>"><div class="translation_menu"><?php echo e(translate_title('Category translate')); ?></div></a>
                                    </li>
                                    <li class="translation_list">
                                        <a href="<?php echo e(route('table.show', 'color')); ?>"><div class="translation_menu"><?php echo e(translate_title('Color translate')); ?></div></a>
                                    </li>
                                    <li class="translation_list">
                                        <a href="<?php echo e(route('table.show', 'product')); ?>"><div class="translation_menu"><?php echo e(translate_title('Product translate')); ?></div></a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="<?php echo e(asset('js/language.js')); ?>"></script>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/resources/views/language/index.blade.php ENDPATH**/ ?>