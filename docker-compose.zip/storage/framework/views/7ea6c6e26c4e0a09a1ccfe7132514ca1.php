

<?php $__env->startSection('title'); ?>
    <?php echo e(translate_title('Edit employee')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="main-content-section">
        <div class="order-section">
            <div class="card">
                <div class="card-header">
                    <h4 class="mt-0 header-title"><?php echo e(translate_title('Edit employee')); ?></h4>
                </div>
                <div class="card-body">
                    <form class="modal-body needs-validation" action="<?php echo e(route('users.update', $user->id)); ?>" method="POST" enctype="multipart/form-data" novalidate>
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div class="row">
                            <div class="position-relative col-6 mb-3">
                                <label for="name" class="form-label"><?php echo e(translate_title('Name')); ?></label>
                                <input type="text" id="name" class="form-control" name="name" value="<?php echo e($user['name']); ?>" required>
                                <div class="invalid-tooltip">
                                    <?php echo e(translate_title('Please enter percent.')); ?>

                                </div>
                            </div>
                            <div class="position-relative col-6 mb-3">
                                <label for="surname" class="form-label"><?php echo e(translate_title('Surname')); ?></label>
                                <input type="text" id="surname" class="form-control" name="surname" value="<?php echo e($user['surname']); ?>" required>
                                <div class="invalid-tooltip">
                                    <?php echo e(translate_title('Please enter percent.')); ?>

                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-6 mb-3">
                                <label for="middlename" class="form-label"><?php echo e(translate_title('Middlename')); ?></label>
                                <input type="text" id="middlename" class="form-control" name="middlename"  value="<?php echo e($user['middlename']); ?>">
                            </div>
                            <div class="col-6 mb-3">
                                <label for="phone" class="form-label"><?php echo e(translate_title('Phone')); ?></label>
                                <input type="text" id="phone" class="form-control" name="phone" value="<?php echo e($user['phone']); ?>">
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-6 mb-3">
                                <img onclick="showImage('<?php echo e($user['image']?asset("storage/users/".$user['image']):asset('icon/no_photo.jpg')); ?>')" data-bs-toggle="modal" data-bs-target="#images-modal" src="<?php echo e($user['image']?asset("storage/users/".$user['image']):asset('icon/no_photo.jpg')); ?>" alt="" height="144px">
                            </div>
                            <div class="col-6 mb-3">
                                <label for="name" class="form-label"><?php echo e(translate_title('Image')); ?></label>
                                <input type="file" id="image" class="form-control" name="image">
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-6 mb-3">
                                <label for="email" class="form-label"><?php echo e(translate_title('Email')); ?></label>
                                <input type="text" id="email" class="form-control" name="email" value="<?php echo e($user['email']); ?>">
                            </div>
                            <div class="col-4 mb-3 d-flex align-items-center">
                                <label for="male" class="me-2 form-check-label">Male</label>
                                <input type="radio" name="gender" id="male" value="<?php echo e(\App\Constants::MALE); ?>" <?php echo e($user['gender'] == \App\Constants::MALE?'checked':''); ?> class="me-4 form-check-input">
                                <label for="female" class="me-2 form-check-label">Female</label>
                                <input type="radio" name="gender" id="female" class="form-check-input" value="<?php echo e(\App\Constants::FEMALE); ?>" <?php echo e($user['gender'] == \App\Constants::FEMALE?'checked':''); ?>>
                            </div>
                            <div class="col-2 mb-3 d-flex align-items-center">
                                <label class="form-check-label me-2" for="status_"><?php echo e(translate_title('Status')); ?></label>
                                <input class="form-check-input rounded-circle" type="checkbox" name="status" id="status_">
                            </div>
                        </div>
                        <div class="row">
                            <div class="position-relative col-6 mb-3">
                                <label class="form-label"><?php echo e(translate_title('Region')); ?></label>
                                <select name="region_id" class="form-control" id="region_id" required>
                                    <option value="" disabled selected><?php echo e(translate_title('Select region')); ?></option>
                                </select>
                                <div class="invalid-tooltip">
                                    <?php echo e(translate_title('Please enter region.')); ?>

                                </div>
                            </div>
                            <div class="position-relative col-6 mb-3">
                                <label class="form-label"><?php echo e(translate_title('District')); ?></label>
                                <select name="district_id" class="form-control" id="district_id" required>
                                    <option value="" disabled selected><?php echo e(translate_title('Select district')); ?></option>
                                </select>
                                <div class="invalid-tooltip">
                                    <?php echo e(translate_title('Please enter district.')); ?>

                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-6 mb-3">
                                <label for="address" class="form-label"><?php echo e(translate_title('Address')); ?></label>
                                <input type="text" id="address" class="form-control" name="address" value="<?php echo e($user->address?$user->address->name:''); ?>">
                            </div>
                            <div class="col-6 mb-3">
                                <label for="password" class="form-label"><?php echo e(translate_title('Current password')); ?></label>
                                <div class="input-group input-group-merge">
                                    <input type="password" id="password" class="form-control" placeholder="Enter current password" name="password">
                                    <div class="input-group-text" data-password="false">
                                        <span class="password-eye"></span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-6 mb-3">
                                <label for="new_password" class="form-label"><?php echo e(translate_title('Password')); ?></label>
                                <div class="input-group input-group-merge">
                                    <input type="password" id="new_password" class="form-control" placeholder="Enter new password" name="new_password">
                                    <div class="input-group-text" data-password="false">
                                        <span class="password-eye"></span>
                                    </div>
                                </div>
                            </div>
                            <div class="col-6 mb-3">
                                <label for="password_confirm" class="form-label"><?php echo e(translate_title('Password confirmation')); ?></label>
                                <div class="input-group input-group-merge">
                                    <input type="password" id="password_confirm" class="form-control" placeholder="Confirm password" name="password_confirmation">
                                    <div class="input-group-text" data-password="false">
                                        <span class="password-eye"></span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-6 mb-3">
                                <div class="form-floating mb-3">
                                    <select class="form-select" name="stuffs_categories_id" id="floatingSelect" aria-label="Floating label select example">
                                        <?php $__currentLoopData = $stuffs_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stuffs_category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($stuffs_category->id); ?>" <?php echo e($user['stuffs_categories_id'] == $stuffs_category->id?'selected':''); ?>><?php echo e($stuffs_category->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <label for="floatingSelect"><?php echo e(translate_title('Stuffs categories')); ?></label>
                                </div>
                            </div>
                        </div>
                        <input type="hidden" name="region" id="region">
                        <input type="hidden" name="district" id="district">
                        <div class="d-flex justify-content-end width_100_percent">
                            <button type="submit" class="btn modal_confirm"><?php echo e(translate_title('Update')); ?></button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <script>
        let page = true
        <?php if($user->address): ?>
            <?php if($user->address->cities): ?>
                let current_region = "<?php echo e($user->address->cities->region?$user->address->cities->region->id:''); ?>"
                let current_district = "<?php echo e($user->address->cities->id??''); ?>"
            <?php else: ?>
                let current_region = ''
                let current_district = ''
            <?php endif; ?>
        <?php else: ?>
            let current_region = ''
            let current_district = ''
        <?php endif; ?>
    </script>
    <script src="<?php echo e(asset('js/cities.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/resources/views/users/edit.blade.php ENDPATH**/ ?>
